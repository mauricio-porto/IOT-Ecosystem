define("converse-dependencies", [
    "locales",
    "backbone.localStorage",
    "jquery.tinysort",
    "strophe",
    "strophe.muc",
    "strophe.roster",
    "strophe.vcard",
    "strophe.disco"
], function() {
    return undefined;
});
