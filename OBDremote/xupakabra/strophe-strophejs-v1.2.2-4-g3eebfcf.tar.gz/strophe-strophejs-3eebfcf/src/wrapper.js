define("strophe", [
    "strophe-core",
    "strophe-bosh",
    "strophe-websocket"
], function (wrapper) {
    return wrapper;
});
